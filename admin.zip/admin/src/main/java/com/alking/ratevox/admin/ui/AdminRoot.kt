package com.alking.ratevox.admin.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Inbox
import androidx.compose.material.icons.rounded.People
import androidx.compose.material.icons.rounded.Reviews
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.alking.ratevox.admin.AdminState
import com.alking.ratevox.admin.AdminVM
import com.alking.ratevox.core.data.Repo
import com.alking.ratevox.core.i18n.trOf
import com.alking.ratevox.core.i18n.tr
import com.alking.ratevox.core.ui.GlowingLogo
import com.alking.ratevox.core.ui.KingFooter
import com.alking.ratevox.core.ui.LanguagePicker
import com.alking.ratevox.core.ui.LoadingBox
import com.alking.ratevox.core.ui.RV
import com.alking.ratevox.core.util.Intents
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

object AR {
    const val DASH = "dash"
    const val REQUESTS = "requests"
    const val PLACES = "places"
    const val PLACE = "place/{id}"
    const val REVIEWS = "reviews"
    const val REPORTS = "reports"
    const val USERS = "users"
    const val USER = "user/{uid}"
    const val CONFIG = "config"
    fun place(id: String) = "place/$id"
    fun user(uid: String) = "user/$uid"
}

@Composable
fun AdminRoot(vm: AdminVM) {
    val st by vm.state.collectAsStateWithLifecycle()
    AnimatedContent(st::class, label = "admin") { _ ->
        when (val s = st) {
            AdminState.Loading -> Box(Modifier.fillMaxSize().background(RV.heroBrush)) { LoadingBox() }
            AdminState.SignedOut -> AdminLogin(vm)
            is AdminState.NotAdmin -> NotAdminScreen(vm, s)
            is AdminState.Ready -> AdminMain(vm)
        }
    }
}

@Composable
private fun Shell(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(RV.heroBrush)) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            GlowingLogo(70.dp)
            Text("RateVox Admin", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text(tr("admin_panel"), color = RV.Gold)
            Spacer(Modifier.height(18.dp))
            Card(shape = RoundedCornerShape(26.dp), elevation = CardDefaults.cardElevation(10.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { content() }
            }
            KingFooter(color = Color.White.copy(alpha = .8f))
        }
    }
}

@Composable
fun AdminLogin(vm: AdminVM) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val lang = vm.lang
    Shell {
        Text(tr("admin_login"), style = MaterialTheme.typography.titleLarge)
        LanguagePicker(vm.lang) { vm.setLanguage(it) }
        OutlinedTextField(
            email, { email = it.trim() }, label = { Text(tr("email")) }, singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Email, null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            pass, { pass = it }, label = { Text(tr("password")) }, singleLine = true,
            leadingIcon = { Icon(Icons.Rounded.Lock, null) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth()
        )
        err?.let { Text(it, color = RV.Coral) }
        Button(
            onClick = {
                if (email.isBlank() || pass.isBlank()) return@Button
                busy = true; err = null
                scope.launch {
                    try {
                        Repo.auth.signInWithEmailAndPassword(email, pass).await()
                    } catch (e: Exception) {
                        err = trOf(lang, "err_wrong_login")
                    }
                    busy = false
                }
            },
            enabled = !busy,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RV.Gold, contentColor = RV.Indigo),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp) else Text(tr("login"))
        }
    }
}

@Composable
fun NotAdminScreen(vm: AdminVM, s: AdminState.NotAdmin) {
    val ctx = LocalContext.current
    val lang = vm.lang
    Shell {
        Text("⛔ " + tr("not_admin_title"), style = MaterialTheme.typography.titleLarge)
        Text(tr("not_admin_sub"), style = MaterialTheme.typography.bodyMedium)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            SelectionContainer {
                Text("UID: ${s.uid}\n${s.email}", modifier = Modifier.padding(12.dp), fontWeight = FontWeight.Bold)
            }
        }
        OutlinedButton(onClick = { Intents.copy(ctx, s.uid, trOf(lang, "copied")) }, modifier = Modifier.fillMaxWidth()) { Text(tr("copy_uid")) }
        Button(onClick = { vm.recheckAdmin() }, modifier = Modifier.fillMaxWidth()) { Text(tr("recheck")) }
        OutlinedButton(onClick = { vm.signOut() }, modifier = Modifier.fillMaxWidth()) { Text(tr("logout")) }
    }
}

private data class ATab(val route: String, val icon: ImageVector, val key: String)

@Composable
fun AdminMain(vm: AdminVM) {
    val nav = rememberNavController()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val tabs = listOf(
        ATab(AR.DASH, Icons.Rounded.Dashboard, "a_dashboard"),
        ATab(AR.REQUESTS, Icons.Rounded.Inbox, "a_requests"),
        ATab(AR.REVIEWS, Icons.Rounded.Reviews, "reviews"),
        ATab(AR.REPORTS, Icons.Rounded.Flag, "a_reports"),
        ATab(AR.USERS, Icons.Rounded.People, "a_users"),
    )
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) NavigationBar {
                tabs.forEach { t ->
                    val badge = when (t.route) {
                        AR.REQUESTS -> pending.size
                        AR.REPORTS -> reports.size
                        else -> 0
                    }
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { nav.goTab(t.route) },
                        icon = {
                            BadgedBox(badge = { if (badge > 0) Badge { Text("$badge") } }) { Icon(t.icon, null) }
                        },
                        label = { Text(tr(t.key), maxLines = 1) }
                    )
                }
            }
        },
        contentWindowInsets = WindowInsets(0)
    ) { pad ->
        NavHost(nav, AR.DASH, Modifier.padding(pad)) {
            composable(AR.DASH) { DashboardScreen(vm, nav) }
            composable(AR.REQUESTS) { RequestsScreen(vm, nav) }
            composable(AR.PLACES) { PlacesScreen(vm, nav) }
            composable(AR.PLACE, arguments = listOf(navArgument("id") { type = NavType.StringType })) { e ->
                PlaceEditScreen(vm, nav, e.arguments?.getString("id").orEmpty())
            }
            composable(AR.REVIEWS) { ReviewsScreen(vm, nav) }
            composable(AR.REPORTS) { ReportsScreen(vm, nav) }
            composable(AR.USERS) { UsersScreen(vm, nav) }
            composable(AR.USER, arguments = listOf(navArgument("uid") { type = NavType.StringType })) { e ->
                UserDetailScreen(vm, nav, e.arguments?.getString("uid").orEmpty())
            }
            composable(AR.CONFIG) { ConfigScreen(vm, nav) }
        }
    }
}

fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
