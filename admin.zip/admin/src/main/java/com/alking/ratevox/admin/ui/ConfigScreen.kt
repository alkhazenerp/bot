package com.alking.ratevox.admin.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.alking.ratevox.admin.AdminVM
import com.alking.ratevox.core.i18n.Lang
import com.alking.ratevox.core.i18n.LocalLang
import com.alking.ratevox.core.i18n.tr
import com.alking.ratevox.core.i18n.trOf
import com.alking.ratevox.core.model.Category
import com.alking.ratevox.core.model.DefaultCategories
import com.alking.ratevox.core.ui.ConfirmDialog
import com.alking.ratevox.core.ui.FontScalePicker
import com.alking.ratevox.core.ui.KingFooter
import com.alking.ratevox.core.ui.LanguagePicker
import com.alking.ratevox.core.ui.RV
import com.alking.ratevox.core.ui.SettingsCard
import com.alking.ratevox.core.ui.ThemePicker
import com.alking.ratevox.core.util.Intents

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfigScreen(vm: AdminVM, nav: NavHostController) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var announcement by remember { mutableStateOf("") }
    var newWord by remember { mutableStateOf("") }
    var editCat by remember { mutableStateOf<Category?>(null) }
    var newCat by remember { mutableStateOf(false) }
    var delCat by remember { mutableStateOf<Category?>(null) }
    var logoutQ by remember { mutableStateOf(false) }
    LaunchedEffect(s.announcement) { announcement = s.announcement }

    val saved: (Boolean) -> Unit = { ok -> Intents.toast(ctx, trOf(lang, if (ok) "saved" else "err_generic")) }

    Scaffold(topBar = { AdminTop("⚙️ " + tr("a_config"), back = { nav.popBackStack() }) }) { pad ->
        Column(
            Modifier.padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------- عام ----------
            SettingsCard("🛠️ " + tr("app_settings")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("auto_approve"), fontWeight = FontWeight.SemiBold)
                        Text(tr("auto_approve_sub"), style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(s.autoApprove, { vm.saveSettings(s.copy(autoApprove = it), saved) })
                }
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("max_strikes"), fontWeight = FontWeight.SemiBold)
                        Text(tr("max_strikes_sub"), style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { if (s.maxStrikes > 1) vm.saveSettings(s.copy(maxStrikes = s.maxStrikes - 1), saved) }) { Icon(Icons.Rounded.Remove, null) }
                    Text("${s.maxStrikes}", style = MaterialTheme.typography.titleLarge)
                    IconButton(onClick = { if (s.maxStrikes < 20) vm.saveSettings(s.copy(maxStrikes = s.maxStrikes + 1), saved) }) { Icon(Icons.Rounded.Add, null) }
                }
                HorizontalDivider()
                Text("📣 " + tr("announcement"), fontWeight = FontWeight.SemiBold)
                OutlinedTextField(announcement, { announcement = it.take(300) }, minLines = 2, placeholder = { Text(tr("announcement_hint")) }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.saveSettings(s.copy(announcement = announcement.trim()), saved) }) { Text(tr("publish")) }
                    OutlinedButton(onClick = { announcement = ""; vm.saveSettings(s.copy(announcement = ""), saved) }) { Text(tr("clear")) }
                }
            }

            // ---------- الكلمات المحظورة ----------
            SettingsCard("🤬 " + tr("bad_words")) {
                Text(tr("bad_words_sub"), style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newWord, { newWord = it }, singleLine = true, placeholder = { Text(tr("add_word")) }, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        val words = newWord.split(",", "،").map { it.trim().lowercase() }.filter { it.isNotBlank() }
                        if (words.isNotEmpty()) {
                            vm.saveSettings(s.copy(badWords = (s.badWords + words).distinct()), saved); newWord = ""
                        }
                    }) { Icon(Icons.Rounded.Add, null, tint = RV.Violet) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    s.badWords.forEach { w ->
                        InputChip(
                            selected = false,
                            onClick = { vm.saveSettings(s.copy(badWords = s.badWords - w), saved) },
                            label = { Text(w) },
                            trailingIcon = { Icon(Icons.Rounded.Close, null, tint = RV.Coral) }
                        )
                    }
                }
            }

            // ---------- الفئات ----------
            SettingsCard("🗂️ " + tr("categories")) {
                s.categories.forEach { c ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(c.emoji, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.label(lang.code), fontWeight = FontWeight.SemiBold)
                            Text(Lang.entries.joinToString(" · ") { c.names[it.code].orEmpty() }, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                        }
                        IconButton(onClick = { editCat = c }) { Icon(Icons.Rounded.Edit, null) }
                        IconButton(onClick = { delCat = c }) { Icon(Icons.Rounded.Delete, null, tint = RV.Coral) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { newCat = true }, colors = ButtonDefaults.buttonColors(containerColor = RV.Gold, contentColor = RV.Indigo)) {
                        Icon(Icons.Rounded.Add, null); Text(tr("add_category"))
                    }
                    OutlinedButton(onClick = { vm.saveSettings(s.copy(categories = DefaultCategories.list), saved) }) { Text(tr("reset_defaults")) }
                }
            }

            // ---------- تطبيق المدير ----------
            SettingsCard("🌍 " + tr("language")) { LanguagePicker(vm.lang) { vm.setLanguage(it) } }
            SettingsCard("🎨 " + tr("appearance")) { ThemePicker(vm.themeMode) { vm.setTheme(it) } }
            SettingsCard("🔤 " + tr("font_size")) { FontScalePicker(vm.fontScale) { vm.setFont(it) } }
            OutlinedButton(onClick = { logoutQ = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Rounded.Logout, null, tint = RV.Coral); Spacer(Modifier.width(6.dp)); Text(tr("logout"), color = RV.Coral)
            }
            KingFooter()
        }
    }

    if (newCat || editCat != null) CategoryDialog(editCat, onSave = { c ->
        val list = s.categories.toMutableList()
        val i = list.indexOfFirst { it.id == c.id }
        if (i >= 0) list[i] = c
        else {
            val other = list.indexOfFirst { it.id == "other" }
            if (other >= 0) list.add(other, c) else list.add(c)
        }
        vm.saveSettings(s.copy(categories = list), saved)
    }, onDismiss = { newCat = false; editCat = null })

    delCat?.let { c ->
        ConfirmDialog(tr("delete"), "${c.emoji} ${c.label(lang.code)}", tr("delete"), danger = true,
            onConfirm = { vm.saveSettings(s.copy(categories = s.categories.filter { it.id != c.id }), saved) },
            onDismiss = { delCat = null })
    }
    if (logoutQ) ConfirmDialog(tr("logout"), tr("logout_q"), tr("logout"), onConfirm = { vm.signOut() }, onDismiss = { logoutQ = false })
}

@Composable
private fun CategoryDialog(initial: Category?, onSave: (Category) -> Unit, onDismiss: () -> Unit) {
    var emoji by remember { mutableStateOf(initial?.emoji ?: "📍") }
    val names = remember { mutableStateOf(Lang.entries.associate { it.code to (initial?.names?.get(it.code) ?: "") }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) tr("add_category") else tr("edit_category")) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(emoji, { emoji = it.take(4) }, label = { Text("Emoji") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Lang.entries.forEach { l ->
                    OutlinedTextField(
                        names.value[l.code].orEmpty(),
                        { v -> names.value = names.value + (l.code to v) },
                        label = { Text("${l.flag} ${l.label}") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = names.value.mapValues { it.value.trim() }
                val base = n["en"].orEmpty().ifBlank { n["ar"].orEmpty() }
                if (base.isBlank()) return@TextButton
                val id = initial?.id ?: base.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "cat_" + System.currentTimeMillis() }
                onSave(Category(id, emoji.ifBlank { "📍" }, n))
                onDismiss()
            }) { Text(tr("save"), fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("cancel")) } }
    )
}
