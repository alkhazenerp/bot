package com.alking.ratevox.admin.ui

import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.alking.ratevox.admin.AdminState
import com.alking.ratevox.admin.AdminVM
import com.alking.ratevox.core.data.Repo
import com.alking.ratevox.core.i18n.LocalLang
import com.alking.ratevox.core.i18n.tr
import com.alking.ratevox.core.model.Review
import com.alking.ratevox.core.ui.AvgBadge
import com.alking.ratevox.core.ui.KingFooter
import com.alking.ratevox.core.ui.PlaceThumb
import com.alking.ratevox.core.ui.RV
import com.alking.ratevox.core.ui.ReviewCard
import com.alking.ratevox.core.ui.SectionTitle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTop(title: String, back: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    TopAppBar(
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = { if (back != null) IconButton(onClick = back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } },
        actions = actions
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(vm: AdminVM, nav: NavHostController) {
    val lang = LocalLang.current.code
    val st by vm.state.collectAsStateWithLifecycle()
    val approved by vm.approved.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val reports by vm.reports.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var counts by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var latest by remember { mutableStateOf<List<Review>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }

    LaunchedEffect(refresh) {
        counts = runCatching { Repo.counts() }.getOrDefault(emptyMap())
        latest = runCatching { Repo.latestReviews(5) }.getOrDefault(emptyList())
    }

    val places = approved.orEmpty()
    val totalRatings = places.sumOf { it.ratingCount }
    val overall = if (totalRatings > 0) places.sumOf { it.ratingSum }.toDouble() / totalRatings else 0.0

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // ---------- الرأس ----------
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 30.dp, bottomEnd = 30.dp))
                .background(RV.heroBrush)
                .statusBarsPadding()
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("👑 " + tr("admin_panel"), color = Color.White, style = MaterialTheme.typography.headlineSmall)
                    Text((st as? AdminState.Ready)?.email.orEmpty(), color = RV.Gold, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { refresh++ }) { Icon(Icons.Rounded.Refresh, null, tint = Color.White) }
                IconButton(onClick = { nav.navigate(AR.CONFIG) }) { Icon(Icons.Rounded.Settings, null, tint = RV.Gold) }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvgBadge(overall, totalRatings, big = true)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(tr("overall_rating"), color = Color.White, fontWeight = FontWeight.Bold)
                    Text(tr("n_reviews", totalRatings), color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        // ---------- البطاقات ----------
        FlowRow(
            Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            maxItemsInEachRow = 2
        ) {
            StatTile("👥", tr("a_users"), counts["users"] ?: -1, RV.Sky, Modifier.weight(1f)) { nav.goTab(AR.USERS) }
            StatTile("📍", tr("a_places"), counts["approved"] ?: places.size.toLong(), RV.Mint, Modifier.weight(1f)) { nav.navigate(AR.PLACES) }
            StatTile("📥", tr("a_requests"), pending.size.toLong(), RV.Gold, Modifier.weight(1f)) { nav.goTab(AR.REQUESTS) }
            StatTile("⭐", tr("reviews"), counts["reviews"] ?: -1, RV.Violet, Modifier.weight(1f)) { nav.goTab(AR.REVIEWS) }
            StatTile("🚩", tr("a_reports"), reports.size.toLong(), RV.Coral, Modifier.weight(1f)) { nav.goTab(AR.REPORTS) }
            StatTile("🚫", tr("a_banned"), counts["banned"] ?: -1, Color(0xFF8D6E63), Modifier.weight(1f)) { nav.goTab(AR.USERS) }
        }

        // ---------- الأعلى تقييماً ----------
        val top = places.filter { it.ratingCount > 0 }.sortedWith(compareByDescending<com.alking.ratevox.core.model.Place> { it.avg }.thenByDescending { it.ratingCount }).take(5)
        if (top.isNotEmpty()) {
            SectionTitle("🏆 " + tr("top_rated"))
            Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.padding(horizontal = 12.dp)) {
                top.forEachIndexed { i, p ->
                    Row(
                        Modifier.fillMaxWidth().clickable { nav.navigate(AR.place(p.id)) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(listOf("🥇", "🥈", "🥉", "4", "5")[i], fontSize = 20.sp, modifier = Modifier.width(30.dp))
                        PlaceThumb(p.thumb, settings.category(p.type).emoji, 42.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(p.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        AvgBadge(p.avg, p.ratingCount)
                    }
                }
            }
        }

        // ---------- توزيع الفئات ----------
        if (places.isNotEmpty()) {
            SectionTitle("📊 " + tr("by_category"))
            Card(shape = RoundedCornerShape(20.dp), modifier = Modifier.padding(horizontal = 12.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val groups = places.groupBy { it.type }.toList().sortedByDescending { it.second.size }
                    val max = groups.maxOf { it.second.size }.toFloat()
                    groups.take(8).forEach { (type, list) ->
                        val c = settings.category(type)
                        val avg = list.sumOf { it.ratingSum }.toDouble() / list.sumOf { it.ratingCount }.coerceAtLeast(1)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${c.emoji} ${c.label(lang)}", Modifier.width(130.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            LinearProgressIndicator(
                                progress = { list.size / max }, color = RV.Violet,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp))
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("${list.size}  ⭐${String.format(Locale.US, "%.1f", avg)}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // ---------- أحدث التقييمات ----------
        if (latest.isNotEmpty()) {
            SectionTitle("🕒 " + tr("latest_reviews"))
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                latest.forEach { r -> ReviewCard(r, showPlace = true, modifier = Modifier.clickable { nav.navigate(AR.place(r.placeId)) }) }
            }
        }
        KingFooter()
    }
}

@Composable
private fun StatTile(emoji: String, label: String, value: Long, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val anim by animateIntAsState(value.coerceAtLeast(0).toInt(), tween(900), label = "stat")
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = .14f)),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(color), contentAlignment = Alignment.Center) {
                Text(emoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(if (value < 0) "—" else "$anim", style = MaterialTheme.typography.titleLarge, color = color)
                Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1)
            }
        }
    }
}
