package com.alking.ratevox.admin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.alking.ratevox.admin.AdminVM
import com.alking.ratevox.core.data.BadWords
import com.alking.ratevox.core.data.Repo
import com.alking.ratevox.core.i18n.tr
import com.alking.ratevox.core.model.AppUser
import com.alking.ratevox.core.model.Report
import com.alking.ratevox.core.model.Review
import com.alking.ratevox.core.ui.Avatar
import com.alking.ratevox.core.ui.ConfirmDialog
import com.alking.ratevox.core.ui.EmptyState
import com.alking.ratevox.core.ui.InputDialog
import com.alking.ratevox.core.ui.LoadingBox
import com.alking.ratevox.core.ui.RV
import com.alking.ratevox.core.ui.ReviewCard
import com.alking.ratevox.core.ui.StarRow
import com.alking.ratevox.core.ui.userLevel
import com.alking.ratevox.core.util.asDate
import kotlinx.coroutines.launch

@Composable
private fun Menu(items: List<Triple<ImageVector, String, () -> Unit>>) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.MoreVert, null) }
        DropdownMenu(open, { open = false }) {
            items.forEach { (i, l, a) -> DropdownMenuItem(text = { Text(l) }, leadingIcon = { Icon(i, null) }, onClick = { open = false; a() }) }
        }
    }
}

/** نافذة حظر مستخدم بسبب */
@Composable
fun BanDialog(name: String, onBan: (String) -> Unit, onDismiss: () -> Unit) {
    InputDialog(
        title = "🚫 " + tr("ban_user") + ": " + name, label = tr("reason"), confirm = tr("ban"),
        singleLine = false, onConfirm = onBan, onDismiss = onDismiss
    )
}

/* ===================== التقييمات ===================== */

@Composable
fun ReviewsScreen(vm: AdminVM, nav: NavHostController) {
    val scope = rememberCoroutineScope()
    var all by remember { mutableStateOf<List<Review>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var flaggedOnly by remember { mutableStateOf(false) }
    var stars by remember { mutableIntStateOf(0) }
    var del by remember { mutableStateOf<Review?>(null) }
    var ban by remember { mutableStateOf<Review?>(null) }
    LaunchedEffect(reload) { all = runCatching { Repo.latestReviews(500) }.getOrDefault(emptyList()) }

    val q = BadWords.normalize(query.trim())
    val list = all?.filter { r ->
        (!flaggedOnly || BadWords.find(r.text) != null) && (stars == 0 || r.stars == stars) &&
                (q.isBlank() || BadWords.normalize(r.text + " " + r.userName + " " + r.placeName).contains(q))
    }

    Scaffold(topBar = {
        AdminTop("⭐ " + tr("reviews") + " (${list?.size ?: 0})") {
            IconButton(onClick = { reload++ }) { Icon(Icons.Rounded.Refresh, null) }
        }
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                query, { query = it }, placeholder = { Text(tr("search_reviews")) }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(flaggedOnly, { flaggedOnly = !flaggedOnly }, label = { Text("⚠️ " + tr("flagged_only")) }) }
                item { FilterChip(stars == 0, { stars = 0 }, label = { Text(tr("all")) }) }
                items((1..5).toList()) { s -> FilterChip(stars == s, { stars = s }, label = { Text("$s ⭐") }) }
            }
            when {
                list == null -> LoadingBox()
                list.isEmpty() -> EmptyState("📭", tr("no_reviews"))
                else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { r ->
                        val flagged = BadWords.find(r.text) != null
                        ReviewCard(
                            r, showPlace = true,
                            modifier = if (flagged) Modifier.padding(0.dp) else Modifier
                        ) {
                            if (flagged) Text("⚠️", modifier = Modifier.padding(end = 4.dp))
                            Menu(
                                listOf(
                                    Triple(Icons.Rounded.Delete, tr("delete"), { del = r }),
                                    Triple(Icons.Rounded.Block, tr("ban_user"), { ban = r }),
                                    Triple(Icons.Rounded.Person, tr("view_user"), { nav.navigate(AR.user(r.uid)) }),
                                    Triple(Icons.Rounded.Place, tr("view_place"), { nav.navigate(AR.place(r.placeId)) }),
                                )
                            )
                        }
                    }
                }
            }
        }
    }
    del?.let { r ->
        ConfirmDialog(tr("delete_review"), "\"${r.text.take(80)}\"", tr("delete"), danger = true, onConfirm = {
            scope.launch {
                runCatching { Repo.deleteReview(r); Repo.closeReportsOf(r.id) }
                all = all?.filter { it.id != r.id }
            }
        }, onDismiss = { del = null })
    }
    ban?.let { r ->
        BanDialog(r.userName, onBan = { reason -> scope.launch { runCatching { Repo.setBan(r.uid, true, reason) } } }, onDismiss = { ban = null })
    }
}

/* ===================== البلاغات ===================== */

@Composable
fun ReportsScreen(vm: AdminVM, nav: NavHostController) {
    val scope = rememberCoroutineScope()
    val reports by vm.reports.collectAsStateWithLifecycle()
    var ban by remember { mutableStateOf<Report?>(null) }

    Scaffold(topBar = { AdminTop("🚩 " + tr("a_reports") + " (${reports.size})") }) { pad ->
        if (reports.isEmpty()) Box(Modifier.padding(pad).fillMaxSize()) { EmptyState("✅", tr("no_reports")) }
        else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(reports, key = { it.id }) { rp ->
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(8.dp), color = RV.Coral) {
                                Text(rp.reason, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Text(rp.createdAt.asDate(true), style = MaterialTheme.typography.labelSmall)
                        }
                        Text("📍 " + rp.placeName, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { nav.navigate(AR.place(rp.placeId)) })
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { nav.navigate(AR.user(rp.reviewUid)) }) {
                            Avatar(rp.reviewUserName, 30.dp)
                            Spacer(Modifier.width(8.dp))
                            Text(rp.reviewUserName, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.width(8.dp))
                            StarRow(rp.reviewStars.toDouble(), 14.dp)
                        }
                        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                            Text(rp.reviewText.ifBlank { "—" }, modifier = Modifier.padding(10.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        runCatching {
                                            Repo.deleteReview(Review(id = rp.reviewId, placeId = rp.placeId, uid = rp.reviewUid))
                                            Repo.closeReportsOf(rp.reviewId)
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RV.Coral)
                            ) { Icon(Icons.Rounded.Delete, null); Text(tr("delete")) }
                            FilledTonalButton(onClick = { ban = rp }) { Icon(Icons.Rounded.Block, null); Text(tr("ban")) }
                            OutlinedButton(onClick = { scope.launch { runCatching { Repo.closeReport(rp.id) } } }) {
                                Icon(Icons.Rounded.DoneAll, null); Text(tr("dismiss"))
                            }
                        }
                    }
                }
            }
        }
    }
    ban?.let { rp ->
        BanDialog(rp.reviewUserName, onBan = { reason ->
            scope.launch {
                runCatching { Repo.setBan(rp.reviewUid, true, reason); Repo.closeReport(rp.id) }
            }
        }, onDismiss = { ban = null })
    }
}

/* ===================== المستخدمون ===================== */

@Composable
fun UsersScreen(vm: AdminVM, nav: NavHostController) {
    var all by remember { mutableStateOf<List<AppUser>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    LaunchedEffect(reload) { all = runCatching { Repo.allUsers() }.getOrDefault(emptyList()) }
    val q = query.trim().lowercase()
    val list = all?.filter { u ->
        (q.isBlank() || u.name.lowercase().contains(q) || u.email.contains(q) || u.uid == query.trim()) &&
                when (filter) {
                    "banned" -> u.banned
                    "warned" -> u.strikes > 0 && !u.banned
                    "unverified" -> !u.verified
                    else -> true
                }
    }

    Scaffold(topBar = {
        AdminTop("👥 " + tr("a_users") + " (${list?.size ?: 0})") {
            IconButton(onClick = { reload++ }) { Icon(Icons.Rounded.Refresh, null) }
        }
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                query, { query = it }, placeholder = { Text(tr("search_users")) }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf("all" to "all", "banned" to "a_banned", "warned" to "warned", "unverified" to "unverified")) { (k, label) ->
                    FilterChip(filter == k, { filter = k }, label = { Text(tr(label)) })
                }
            }
            when {
                list == null -> LoadingBox()
                list.isEmpty() -> EmptyState("👤", tr("no_users"))
                else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.uid }) { u -> UserRow(u) { nav.navigate(AR.user(u.uid)) } }
                }
            }
        }
    }
}

@Composable
private fun UserRow(u: AppUser, onClick: () -> Unit) {
    val (lvlEmoji, _) = userLevel(u.reviewsCount)
    Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(u.name, 44.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(u.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (u.verified) Icon(Icons.Rounded.Verified, null, tint = RV.Sky, modifier = Modifier.padding(start = 4.dp))
                }
                Text(u.email, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Text("$lvlEmoji ${u.reviewsCount} ⭐   ⚠️ ${u.strikes}   🕒 ${u.createdAt.asDate()}", style = MaterialTheme.typography.labelSmall)
            }
            if (u.banned) Surface(shape = RoundedCornerShape(8.dp), color = RV.Coral) {
                Text(tr("banned"), color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
fun UserDetailScreen(vm: AdminVM, nav: NavHostController, uid: String) {
    val scope = rememberCoroutineScope()
    var user by remember { mutableStateOf<AppUser?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var reviews by remember { mutableStateOf<List<Review>>(emptyList()) }
    var ban by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<Review?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        user = Repo.getUser(uid)
        reviews = runCatching { Repo.userReviews(uid) }.getOrDefault(emptyList())
        loaded = true
    }

    Scaffold(topBar = { AdminTop("👤 " + (user?.name ?: ""), back = { nav.popBackStack() }) }) { pad ->
        val u = user
        if (!loaded) {
            LoadingBox(Modifier.padding(pad).fillMaxSize()); return@Scaffold
        }
        if (u == null) {
            Box(Modifier.padding(pad)) { EmptyState("❓", tr("user_not_found")) }; return@Scaffold
        }
        LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Avatar(u.name, 72.dp)
                        Text(u.name, style = MaterialTheme.typography.titleLarge)
                        Text(u.email)
                        Text("UID: ${u.uid}", style = MaterialTheme.typography.labelSmall)
                        Text("🕒 ${u.createdAt.asDate(true)}   ⭐ ${u.reviewsCount}   ⚠️ ${u.strikes}")
                        if (u.banned) Text("🚫 " + tr("banned") + (if (u.banReason.isNotBlank()) ": " + u.banReason else ""), color = RV.Coral, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("verified"))
                            Spacer(Modifier.width(8.dp))
                            Switch(u.verified, { v ->
                                scope.launch { runCatching { Repo.setUserVerified(u.uid, v) }; user = u.copy(verified = v) }
                            })
                        }
                        if (u.banned) Button(
                            onClick = { scope.launch { runCatching { Repo.setBan(u.uid, false) }; reload++ } },
                            colors = ButtonDefaults.buttonColors(containerColor = RV.Mint)
                        ) { Text("✅ " + tr("unban")) }
                        else Button(onClick = { ban = true }, colors = ButtonDefaults.buttonColors(containerColor = RV.Coral)) {
                            Icon(Icons.Rounded.Block, null); Text(tr("ban_user"))
                        }
                    }
                }
            }
            item { Text("⭐ " + tr("reviews") + " (${reviews.size})", style = MaterialTheme.typography.titleMedium) }
            items(reviews, key = { it.id }) { r ->
                ReviewCard(r, showPlace = true, modifier = Modifier.clickable { nav.navigate(AR.place(r.placeId)) }) {
                    IconButton(onClick = { del = r }) { Icon(Icons.Rounded.Delete, null, tint = RV.Coral) }
                }
            }
        }
    }
    if (ban) user?.let { u ->
        BanDialog(u.name, onBan = { reason -> scope.launch { runCatching { Repo.setBan(u.uid, true, reason) }; reload++ } }, onDismiss = { ban = false })
    }
    del?.let { r ->
        ConfirmDialog(tr("delete_review"), "\"${r.text.take(80)}\"", tr("delete"), danger = true, onConfirm = {
            scope.launch { runCatching { Repo.deleteReview(r); Repo.closeReportsOf(r.id) }; reload++ }
        }, onDismiss = { del = null })
    }
}
