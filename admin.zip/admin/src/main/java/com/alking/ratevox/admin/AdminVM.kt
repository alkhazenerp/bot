package com.alking.ratevox.admin

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alking.ratevox.core.data.BadWords
import com.alking.ratevox.core.data.Prefs
import com.alking.ratevox.core.data.Repo
import com.alking.ratevox.core.i18n.Lang
import com.alking.ratevox.core.model.AppSettings
import com.alking.ratevox.core.model.Place
import com.alking.ratevox.core.model.Report
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AdminState {
    data object Loading : AdminState
    data object SignedOut : AdminState
    data class NotAdmin(val uid: String, val email: String) : AdminState
    data class Ready(val uid: String, val email: String) : AdminState
}

@OptIn(ExperimentalCoroutinesApi::class)
class AdminVM(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    var lang by mutableStateOf(if (prefs.lang.isBlank()) Lang.AR else Lang.of(prefs.lang))
        private set
    var themeMode by mutableIntStateOf(prefs.themeMode)
        private set
    var fontScale by mutableFloatStateOf(prefs.fontScale)
        private set

    private val fbUser = MutableStateFlow(Repo.auth.currentUser)
    private val recheck = MutableStateFlow(0)
    private val listener = FirebaseAuth.AuthStateListener { fbUser.value = it.currentUser }

    init {
        Repo.auth.addAuthStateListener(listener)
    }

    override fun onCleared() {
        Repo.auth.removeAuthStateListener(listener)
    }

    val state: StateFlow<AdminState> = combine(fbUser, recheck) { u, _ -> u }.flatMapLatest { fu ->
        if (fu == null) flowOf<AdminState>(AdminState.SignedOut)
        else flow {
            emit(AdminState.Loading)
            emit(
                if (Repo.isAdmin(fu.uid)) AdminState.Ready(fu.uid, fu.email.orEmpty())
                else AdminState.NotAdmin(fu.uid, fu.email.orEmpty())
            )
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, AdminState.Loading)

    private val ready = state.map { it is AdminState.Ready }

    val settings: StateFlow<AppSettings> = ready.flatMapLatest { if (it) Repo.settingsFlow() else flowOf(AppSettings()) }
        .onEach { BadWords.remote = it.badWords }
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val pending: StateFlow<List<Place>> = ready.flatMapLatest {
        if (it) Repo.placesByStatusFlow(Place.STATUS_PENDING) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val approved: StateFlow<List<Place>?> = ready.flatMapLatest {
        if (it) Repo.approvedPlacesFlow() else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val reports: StateFlow<List<Report>> = ready.flatMapLatest {
        if (it) Repo.openReportsFlow() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun recheckAdmin() {
        recheck.value++
    }

    fun signOut() = Repo.auth.signOut()

    fun setLanguage(l: Lang) {
        lang = l; prefs.lang = l.code
    }

    fun setTheme(m: Int) {
        themeMode = m; prefs.themeMode = m
    }

    fun setFont(s: Float) {
        fontScale = s; prefs.fontScale = s
    }

    /** حفظ إعدادات التطبيق العامة (config/app) */
    fun saveSettings(s: AppSettings, done: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            done(runCatching { Repo.saveSettings(s) }.isSuccess)
        }
    }
}
