package com.alking.ratevox.admin.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.alking.ratevox.admin.AdminVM
import com.alking.ratevox.core.data.BadWords
import com.alking.ratevox.core.data.Repo
import com.alking.ratevox.core.i18n.LocalLang
import com.alking.ratevox.core.i18n.tr
import com.alking.ratevox.core.i18n.trOf
import com.alking.ratevox.core.model.AppSettings
import com.alking.ratevox.core.model.Place
import com.alking.ratevox.core.ui.AvgBadge
import com.alking.ratevox.core.ui.ConfirmDialog
import com.alking.ratevox.core.ui.EmptyState
import com.alking.ratevox.core.ui.InputDialog
import com.alking.ratevox.core.ui.LoadingBox
import com.alking.ratevox.core.ui.PlaceDraft
import com.alking.ratevox.core.ui.PlaceForm
import com.alking.ratevox.core.ui.PlaceThumb
import com.alking.ratevox.core.ui.RV
import com.alking.ratevox.core.util.Intents
import com.alking.ratevox.core.util.asDate
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@Composable
fun AdminPlaceRow(p: Place, settings: AppSettings, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val lang = LocalLang.current.code
    val c = settings.category(p.type)
    Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            PlaceThumb(p.thumb, c.emoji, 60.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (p.featured) Text("🏆 ")
                    Text(p.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("${c.emoji} ${c.label(lang)} • ${p.address}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "👤 ${p.addedByName.ifBlank { "—" }}  •  ${p.createdAt.asDate(true)}",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (p.status == Place.STATUS_APPROVED) AvgBadge(p.avg, p.ratingCount)
            trailing()
        }
    }
}

/* ===================== طلبات الإضافة ===================== */

@Composable
fun RequestsScreen(vm: AdminVM, nav: NavHostController) {
    val scope = rememberCoroutineScope()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var reject by remember { mutableStateOf<Place?>(null) }

    Scaffold(topBar = { AdminTop("📥 " + tr("a_requests") + " (${pending.size})") }) { pad ->
        if (pending.isEmpty()) Box(Modifier.padding(pad).fillMaxSize()) { EmptyState("🎉", tr("no_pending")) }
        else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(pending, key = { it.id }) { p ->
                Column {
                    AdminPlaceRow(p, settings, onClick = { nav.navigate(AR.place(p.id)) })
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val flagged = BadWords.find(p.name + " " + p.address + " " + p.description) != null
                        if (flagged) Text("⚠️ " + tr("contains_bad_words"), color = RV.Coral, style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterVertically))
                        Spacer(Modifier.weight(1f))
                        FilledTonalButton(onClick = { reject = p }) { Icon(Icons.Rounded.Close, null, tint = RV.Coral); Text(tr("reject")) }
                        Button(
                            onClick = { scope.launch { runCatching { Repo.setPlaceStatus(p.id, Place.STATUS_APPROVED) } } },
                            colors = ButtonDefaults.buttonColors(containerColor = RV.Mint)
                        ) { Icon(Icons.Rounded.Check, null); Text(tr("approve")) }
                    }
                }
            }
        }
    }
    reject?.let { p ->
        InputDialog(
            title = tr("reject") + ": " + p.name, label = tr("reason"), confirm = tr("reject"), singleLine = false,
            onConfirm = { r -> scope.launch { runCatching { Repo.setPlaceStatus(p.id, Place.STATUS_REJECTED, r) } } },
            onDismiss = { reject = null }
        )
    }
}

/* ===================== كل الأماكن ===================== */

@Composable
fun PlacesScreen(vm: AdminVM, nav: NavHostController) {
    val approved by vm.approved.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var tab by remember { mutableStateOf(Place.STATUS_APPROVED) }
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var rejected by remember { mutableStateOf<List<Place>?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, reload) {
        if (tab == Place.STATUS_REJECTED) rejected = runCatching { Repo.placesByStatus(Place.STATUS_REJECTED) }.getOrDefault(emptyList())
    }
    val source = if (tab == Place.STATUS_APPROVED) approved else rejected
    val q = BadWords.normalize(query.trim())
    val list = source?.filter {
        (cat.isBlank() || it.type == cat) && (q.isBlank() || BadWords.normalize(it.name).contains(q) || BadWords.normalize(it.address).contains(q))
    }?.sortedByDescending { it.createdAt }

    Scaffold(
        topBar = { AdminTop("📍 " + tr("a_places"), back = { nav.popBackStack() }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate(AR.place("new")) },
                containerColor = RV.Gold, contentColor = RV.Indigo,
                icon = { Icon(Icons.Rounded.Add, null) }, text = { Text(tr("add_place")) }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(tab == Place.STATUS_APPROVED, { tab = Place.STATUS_APPROVED }, label = { Text(tr("st_approved") + " (${approved?.size ?: 0})") })
                FilterChip(tab == Place.STATUS_REJECTED, { tab = Place.STATUS_REJECTED; reload++ }, label = { Text(tr("st_rejected")) })
            }
            OutlinedTextField(
                query, { query = it }, placeholder = { Text(tr("search_hint")) }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            )
            CategoryChips(settings, cat) { cat = it }
            when {
                list == null -> LoadingBox()
                list.isEmpty() -> EmptyState("🔎", tr("no_places"))
                else -> LazyColumn(contentPadding = PaddingValues(12.dp, 6.dp, 12.dp, 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.id }) { p -> AdminPlaceRow(p, settings, onClick = { nav.navigate(AR.place(p.id)) }) }
                }
            }
        }
    }
}

@Composable
fun CategoryChips(settings: AppSettings, cat: String, onPick: (String) -> Unit) {
    val lang = LocalLang.current.code
    androidx.compose.foundation.lazy.LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { FilterChip(cat.isBlank(), { onPick("") }, label = { Text(tr("all")) }) }
        items(settings.categories) { c ->
            FilterChip(cat == c.id, { onPick(if (cat == c.id) "" else c.id) }, label = { Text("${c.emoji} ${c.label(lang)}") })
        }
    }
}

/* ===================== تعديل / مراجعة / إضافة مكان ===================== */

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlaceEditScreen(vm: AdminVM, nav: NavHostController, id: String) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val isNew = id == "new"
    var place by remember { mutableStateOf<Place?>(if (isNew) Place() else null) }
    var fullImage by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(isNew) }
    var busy by remember { mutableStateOf(false) }
    var formKey by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf(false) }
    var reject by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (!isNew) {
            place = runCatching { Repo.placeFlow(id).first() }.getOrNull()
            if (place?.hasImage == true) fullImage = Repo.placeImage(id)
            loaded = true
            formKey++
        }
    }

    Scaffold(topBar = {
        AdminTop(if (isNew) "➕ " + tr("add_place") else "✏️ " + (place?.name ?: ""), back = { nav.popBackStack() }) {
            if (!isNew && place != null) IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Rounded.Delete, null, tint = RV.Coral) }
        }
    }) { pad ->
        val p = place
        if (!loaded) {
            LoadingBox(Modifier.padding(pad).fillMaxSize()); return@Scaffold
        }
        if (p == null) {
            Box(Modifier.padding(pad)) { EmptyState("❓", tr("place_not_found")) }; return@Scaffold
        }
        Column(
            Modifier.padding(pad).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!isNew) {
                // ---- الحالة والإجراءات ----
                val (color, key) = when (p.status) {
                    Place.STATUS_APPROVED -> RV.Mint to "st_approved"
                    Place.STATUS_REJECTED -> RV.Coral to "st_rejected"
                    else -> RV.Gold to "st_pending"
                }
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = color.copy(alpha = .12f))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = RoundedCornerShape(10.dp), color = color) {
                                Text(tr(key), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
                            }
                            Spacer(Modifier.width(8.dp))
                            if (p.status == Place.STATUS_APPROVED) {
                                AvgBadge(p.avg, p.ratingCount)
                                Text("  " + tr("n_reviews", p.ratingCount), style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        Text(
                            "👤 " + p.addedByName.ifBlank { "—" } + "   🕒 " + p.createdAt.asDate(true),
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.clickable(enabled = p.addedBy.isNotBlank()) { nav.navigate(AR.user(p.addedBy)) }
                        )
                        if (p.rejectReason.isNotBlank()) Text(tr("reason") + ": " + p.rejectReason, color = RV.Coral, style = MaterialTheme.typography.bodySmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (p.status != Place.STATUS_APPROVED) Button(
                                onClick = {
                                    scope.launch {
                                        runCatching { Repo.setPlaceStatus(p.id, Place.STATUS_APPROVED) }
                                        place = p.copy(status = Place.STATUS_APPROVED, rejectReason = "")
                                        Intents.toast(ctx, trOf(lang, "done"))
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RV.Mint)
                            ) { Icon(Icons.Rounded.Check, null); Text(tr("approve")) }
                            if (p.status != Place.STATUS_REJECTED) OutlinedButton(onClick = { reject = true }) {
                                Icon(Icons.Rounded.Close, null, tint = RV.Coral); Text(tr("reject"))
                            }
                            if (p.status == Place.STATUS_APPROVED) OutlinedButton(onClick = {
                                scope.launch {
                                    runCatching { Repo.setFeatured(p.id, !p.featured) }
                                    place = p.copy(featured = !p.featured)
                                }
                            }) {
                                Icon(if (p.featured) Icons.Rounded.Star else Icons.Rounded.StarOutline, null, tint = RV.Gold)
                                Text(if (p.featured) tr("unfeature") else tr("feature"))
                            }
                        }
                    }
                }
            }

            androidx.compose.runtime.key(formKey) {
                PlaceForm(
                    initial = PlaceDraft.from(p),
                    categories = settings.categories,
                    submitLabel = when {
                        isNew -> tr("add_place")
                        p.status == Place.STATUS_PENDING -> tr("save_approve")
                        else -> tr("save")
                    },
                    showDisclaimer = false,
                    busy = busy,
                    existingFullImage = fullImage,
                    onSubmit = { d ->
                        busy = true
                        scope.launch {
                            try {
                                if (isNew) {
                                    val newId = Repo.submitPlace(
                                        Place(
                                            name = d.name, type = d.type, address = d.address, phone = d.phone, mapsUrl = d.mapsUrl,
                                            description = d.description, lat = d.lat, lng = d.lng, thumb = d.thumb,
                                            status = Place.STATUS_APPROVED, addedBy = Repo.uid.orEmpty(), addedByName = "Admin",
                                            createdAt = System.currentTimeMillis()
                                        ),
                                        d.fullImage?.takeIf { it.isNotBlank() }
                                    )
                                    Intents.toast(ctx, trOf(lang, "done"))
                                    nav.popBackStack()
                                    nav.navigate(AR.place(newId))
                                } else {
                                    val status = if (p.status == Place.STATUS_PENDING) Place.STATUS_APPROVED else p.status
                                    val updated = p.copy(
                                        name = d.name, type = d.type, address = d.address, phone = d.phone, mapsUrl = d.mapsUrl,
                                        description = d.description, lat = d.lat, lng = d.lng, thumb = d.thumb, status = status,
                                        rejectReason = if (status == Place.STATUS_APPROVED) "" else p.rejectReason
                                    )
                                    Repo.updatePlace(updated, d.fullImage)
                                    place = updated
                                    d.fullImage?.let { fi -> fullImage = fi.ifBlank { null } }
                                    Intents.toast(ctx, trOf(lang, "saved"))
                                }
                            } catch (e: Exception) {
                                Intents.toast(ctx, trOf(lang, "err_generic") + " " + (e.message ?: ""))
                            }
                            busy = false
                        }
                    }
                )
            }
        }
    }

    if (confirmDelete) place?.let { p ->
        ConfirmDialog(
            tr("delete_place"), tr("delete_place_q", p.name), tr("delete"), danger = true,
            onConfirm = {
                scope.launch {
                    runCatching { Repo.deletePlace(p.id) }
                    nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false }
        )
    }
    if (reject) place?.let { p ->
        InputDialog(
            title = tr("reject"), label = tr("reason"), confirm = tr("reject"), singleLine = false,
            onConfirm = { r ->
                scope.launch {
                    runCatching { Repo.setPlaceStatus(p.id, Place.STATUS_REJECTED, r) }
                    place = p.copy(status = Place.STATUS_REJECTED, rejectReason = r, featured = false)
                }
            },
            onDismiss = { reject = false }
        )
    }
}
