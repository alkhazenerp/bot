package com.alking.ratevox.admin

import android.app.Application
import com.alking.ratevox.core.ui.initOsm

class AdminApp : Application() {
    override fun onCreate() {
        super.onCreate()
        initOsm(this)
    }
}
