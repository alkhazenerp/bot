package com.alking.ratevox.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.alking.ratevox.admin.ui.AdminRoot
import com.alking.ratevox.core.i18n.Lang
import com.alking.ratevox.core.ui.FirebaseCheck
import com.alking.ratevox.core.ui.FirebaseSetupScreen
import com.alking.ratevox.core.ui.RateVoxTheme

class AdminActivity : ComponentActivity() {
    private val vm: AdminVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (!FirebaseCheck.ready(this)) {
            // لا يوجد google-services.json: نعرض شاشة الإعداد بدل أن ينهار التطبيق
            setContent {
                RateVoxTheme(lang = Lang.device(), themeMode = 0, fontScale = 1f) { FirebaseSetupScreen() }
            }
            return
        }
        setContent {
            RateVoxTheme(lang = vm.lang, themeMode = vm.themeMode, fontScale = vm.fontScale) {
                AdminRoot(vm)
            }
        }
    }
}
