plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.alking.ratevox.admin"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alking.ratevox.admin"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":core"))
}

// يُفعَّل Firebase فقط عند وجود google-services.json داخل هذا المجلد.
// بدونه يُبنى التطبيق ويعرض شاشة "إعداد Firebase" بدل أن يفشل البناء.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
} else {
    logger.warn("RateVox: google-services.json is missing in '${project.name}' - Firebase disabled (setup screen will be shown)")
}
